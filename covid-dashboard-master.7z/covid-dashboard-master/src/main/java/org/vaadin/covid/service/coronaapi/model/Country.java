package org.vaadin.covid.service.coronaapi.model;

import lombok.Data;

import java.util.List;

@Data
public class Country implements Comparable<Country> {

	private Coordinates coordinates;
    private String name;
    private String code;
    private Long population;
    private LatestData latest_data;
    private List<Timeline> timeline;
	
    public Coordinates getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getPopulation() {
		return population;
	}

	public void setPopulation(Long population) {
		this.population = population;
	}

	public LatestData getLatest_data() {
		return latest_data;
	}

	public void setLatest_data(LatestData latest_data) {
		this.latest_data = latest_data;
	}

	public List<Timeline> getTimeline() {
		return timeline;
	}

	public void setTimeline(List<Timeline> timeline) {
		this.timeline = timeline;
	}



    @Override
    public int compareTo(Country country) {
        return name.compareTo(country.getName());
    }

}
