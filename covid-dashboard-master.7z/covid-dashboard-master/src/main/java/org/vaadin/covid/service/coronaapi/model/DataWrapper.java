package org.vaadin.covid.service.coronaapi.model;

import lombok.Data;

@Data
public class DataWrapper<T> {

    public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	private T data;

}
