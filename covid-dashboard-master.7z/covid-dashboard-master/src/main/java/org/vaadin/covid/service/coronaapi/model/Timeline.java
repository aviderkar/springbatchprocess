package org.vaadin.covid.service.coronaapi.model;

import lombok.Data;

import java.time.LocalDate;

@Data
public class Timeline {

	private LocalDate date;
    private Long deaths;
    private Long confirmed;
    private Long recovered;
    private Long new_confirmed;
    private Long new_recovered;
    private Long new_deaths;
	
    public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Long getDeaths() {
		return deaths;
	}
	public void setDeaths(Long deaths) {
		this.deaths = deaths;
	}
	public Long getConfirmed() {
		return confirmed;
	}
	public void setConfirmed(Long confirmed) {
		this.confirmed = confirmed;
	}
	public Long getRecovered() {
		return recovered;
	}
	public void setRecovered(Long recovered) {
		this.recovered = recovered;
	}
	public Long getNew_confirmed() {
		return new_confirmed;
	}
	public void setNew_confirmed(Long new_confirmed) {
		this.new_confirmed = new_confirmed;
	}
	public Long getNew_recovered() {
		return new_recovered;
	}
	public void setNew_recovered(Long new_recovered) {
		this.new_recovered = new_recovered;
	}
	public Long getNew_deaths() {
		return new_deaths;
	}
	public void setNew_deaths(Long new_deaths) {
		this.new_deaths = new_deaths;
	}


}
