package org.vaadin.covid.service.coronaapi.model;

import lombok.Data;

@Data
public class Coordinates {

    private Long latitude;
    private Long longitude;

}
