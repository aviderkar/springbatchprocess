package org.vaadin.covid.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Day {

    public Day(LocalDate date, Long cases, Long deaths, Long recovered, Long newCases, Long newDeaths,
			Long newRecovered) {
		super();
		this.date = date;
		this.cases = cases;
		this.deaths = deaths;
		this.recovered = recovered;
		this.newCases = newCases;
		this.newDeaths = newDeaths;
		this.newRecovered = newRecovered;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Long getCases() {
		return cases;
	}

	public void setCases(Long cases) {
		this.cases = cases;
	}

	public Long getDeaths() {
		return deaths;
	}

	public void setDeaths(Long deaths) {
		this.deaths = deaths;
	}

	public Long getRecovered() {
		return recovered;
	}

	public void setRecovered(Long recovered) {
		this.recovered = recovered;
	}

	public Long getNewCases() {
		return newCases;
	}

	public void setNewCases(Long newCases) {
		this.newCases = newCases;
	}

	public Long getNewDeaths() {
		return newDeaths;
	}

	public void setNewDeaths(Long newDeaths) {
		this.newDeaths = newDeaths;
	}

	public Long getNewRecovered() {
		return newRecovered;
	}

	public void setNewRecovered(Long newRecovered) {
		this.newRecovered = newRecovered;
	}

	private LocalDate date;

    private Long cases;

    private Long deaths;

    private Long recovered;

    private Long newCases;

    private Long newDeaths;

    private Long newRecovered;

	

}
